export default function Panel() {
  return <div></div>;
}
